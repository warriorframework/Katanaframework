/**
 * Load the libraries for the Index Terms page.
 */
define(["require", "config"], function() {
    require([
        'menu',
        'expand',
        'template-module-loader'
    ]);
});